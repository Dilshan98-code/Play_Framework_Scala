package Models
// student model which stores student data
class Student(index: Int, registrationNo: String, name: String)
{
  var IndexNo : Int = index
  var RegistrationNo: String = registrationNo
  var Name : String = name

}

